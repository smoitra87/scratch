#include<stdio.h>


const char* hello_str = "Always Hello..!\n";
