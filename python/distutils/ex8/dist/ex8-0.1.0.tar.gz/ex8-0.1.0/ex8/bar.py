""" Just a bar module """

def foo() :
	pass
