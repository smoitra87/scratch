""" This is the ex7 package """

import foo
import bar

