Non-pure Python Package
Tests can be run by building in place
$ python setup.py build_ext --inplace
$ nosetests

Test cases pass 
